from flask import Flask, render_template, request
from wtforms import Form, FloatField
from wtforms.validators import DataRequired
import pickle
import os
import numpy as np

app = Flask(__name__)

##### Pickle load for Prediction
cur_dir = os.path.dirname(__file__)
ppn = pickle.load(open(os.path.join(cur_dir,
                 'pkl_objects',
                 'ppn.pkl'), 'rb'))
lr = pickle.load(open(os.path.join(cur_dir,
                 'pkl_objects',
                 'lr.pkl'), 'rb'))
svm = pickle.load(open(os.path.join(cur_dir,
                 'pkl_objects',
                 'svm.pkl'), 'rb'))
tree = pickle.load(open(os.path.join(cur_dir,
                 'pkl_objects',
                 'tree.pkl'), 'rb'))
forest = pickle.load(open(os.path.join(cur_dir,
                 'pkl_objects',
                'forest.pkl'), 'rb'))
knn = pickle.load(open(os.path.join(cur_dir,
                 'pkl_objects',
                 'knn.pkl'), 'rb'))

def ppn_classifier(X):
    y_ppn    =  ppn.predict(X)[0]
    return y_ppn

def lr_classifier(X):
    y_lr    =  lr.predict(X)[0]
    return y_lr

def svm_classifier(X):
    y_svm    =  svm.predict(X)[0]
    return y_svm

def tree_classifier(X):
    y_tree   =  tree.predict(X)[0]
    return y_tree

def forest_classifier(X):
    y_forest    =  forest.predict(X)[0]
    return y_forest

def knn_classifier(X):
    y_knn    =  knn.predict(X)[0]
    return y_knn



######## Flask
class InputForm(Form):
    # https://www.reddit.com/r/flask/comments/2kj2l2/afwtforms_generating_a_form_programmatically/
    # https://stackoverflow.com/questions/22203159/generate-a-dynamic-form-using-flask-wtf-and-sqlalchemy
    # https://stackoverflow.com/questions/39640024/create-dynamic-fields-in-wtform-in-flask
    # http://nullege.com/codes/show/src@v@i@viaduct-HEAD@viaduct@forms@booksales.py/12/flask.ext.wtf.FloatField
    #RM = FloatField('RM:',[validators.DataRequired()])
    A1 = FloatField('A1:',validators=[DataRequired()])
    A2 = FloatField('A2:',validators=[DataRequired()])
    A3 = FloatField('A3:',validators=[DataRequired()])
    A4 = FloatField('A4:',validators=[DataRequired()])
    B1 = FloatField('B1:',validators=[DataRequired()])
    B2 = FloatField('B2:',validators=[DataRequired()])
    B3 = FloatField('B3:',validators=[DataRequired()])
    C1 = FloatField('C1:',validators=[DataRequired()])
    C2 = FloatField('C2:',validators=[DataRequired()])
    D1 = FloatField('D1:',validators=[DataRequired()])
    D2 = FloatField('D2:',validators=[DataRequired()])
    E1 = FloatField('E1:',validators=[DataRequired()])
    E2 = FloatField('E2:',validators=[DataRequired()])
    F1 = FloatField('F1:',validators=[DataRequired()])
    G1 = FloatField('G1:',validators=[DataRequired()])
    G2 = FloatField('G2:',validators=[DataRequired()])
    G3 = FloatField('G3:',validators=[DataRequired()])
    G4 = FloatField('G4:',validators=[DataRequired()])

@app.route('/')
def index():
    form = InputForm(request.form)
    return render_template('index.html', form=form)

@app.route('/results', methods=['POST'])
def results():
    form = InputForm(request.form)
    if request.method == 'POST' and form.validate():
        A1 = form.A1.data
        A2 = form.A2.data
        A3 = form.A3.data
        A4 = form.A4.data
        B1 = form.B1.data
        B2 = form.B2.data
        B3 = form.B3.data
        C1 = form.C1.data
        C2 = form.C2.data
        D1 = form.D1.data
        D2 = form.D2.data
        E1 = form.E1.data
        E2 = form.E2.data
        F1 = form.F1.data
        G1 = form.G1.data
        G2 = form.G2.data
        G3 = form.G3.data
        G4 = form.G4.data
       
        X = np.asarray([A1,A2,A3,A4,B1,B2,B3,C1,C2,D1,D2,E1,E2,F1,G1,G2,G3,G4])     
        ### Standardizing the features                        
        from sklearn.preprocessing import StandardScaler
        sc = StandardScaler()
        sc.fit(X)
        X_std = sc.transform(X)
        
        #call the cllasifier 
        y_ppn    = ppn_classifier(X_std)
        y_lr     = lr_classifier(X_std)
        y_svm    = svm_classifier(X_std)
        y_tree   = tree_classifier(X)
        y_forest = forest_classifier(X)
        #y_knn    = knn_classifier(X_std)
        y_knn     = 'Under construction'
                                  
        return render_template('results.html',
                                A1=A1,
                                A2=A2,
                                A3=A3,
                                A4=A4,
                                B1=B1,
                                B2=B2,
                                B3=B3,
                                C1=C1,
                                C2=C2,
                                D1=D1,
                                D2=D2,
                                E1=E1,
                                E2=E2,
                                F1=F1,
                                G1=G1,
                                G2=G2,
                                G3=G3,
                                G4=G4,
                                y_ppn = y_ppn,
                                y_lr  = y_lr,
                                y_svm = y_svm,
                                y_tree = y_tree,
                                y_forest = y_forest,
                               y_knn = y_knn)
    return render_template('index.html', form=form)

if __name__ == '__main__':
    app.run(debug=True)

